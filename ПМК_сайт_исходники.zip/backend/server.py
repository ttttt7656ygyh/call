import os
import sys
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, Depends, HTTPException, Header, Body, Query, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import (
    create_engine, Column, Integer, String, Text, DateTime, Float,
    ForeignKey, func, UniqueConstraint,
)
from sqlalchemy.orm import (
    sessionmaker, declarative_base, Session, relationship, joinedload,
)
from jose import JWTError, jwt
from passlib.context import CryptContext


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


load_dotenv(app_dir() / ".env")

BASE_DIR = app_dir()
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)
WEB_DIR = BASE_DIR / "web"
ALLOWED_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
MAX_UPLOAD_BYTES = 5 * 1024 * 1024

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg://postgres:123@localhost:5432/pmk_db",
)
SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-production")
ALGORITHM = "HS256"
TOKEN_TTL_MINUTES = 60 * 24 * 7
ALLOWED_ORIGINS = [
    o.strip() for o in os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",") if o.strip()
]

CATEGORIES = {
    "worship": "Богослужение",
    "help": "Помощь",
    "pilgrimage": "Паломничество",
    "creativity": "Творчество",
    "education": "Образование",
}


engine_kwargs = {}
if DATABASE_URL.startswith("sqlite"):
    engine_kwargs["connect_args"] = {"check_same_thread": False}

engine = create_engine(DATABASE_URL, **engine_kwargs)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    login = Column(String(50), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    name = Column(String(100))
    full_name = Column(String(150))
    phone = Column(String(20))
    age = Column(Integer)
    email = Column(String(100))
    role = Column(String(20), default="user")
    avatar = Column(String(500))
    created_at = Column(DateTime, server_default=func.now())


class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    photo_url = Column(Text, nullable=True)
    event_date = Column(DateTime, nullable=False)
    location = Column(String(255), nullable=True)
    lat = Column(Float, nullable=True)
    lng = Column(Float, nullable=True)
    category = Column(String(30), nullable=True)
    organizer_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    organizer = relationship("User")


class Application(Base):
    __tablename__ = "applications"
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    status = Column(String(20), default="pending")
    message = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    user = relationship("User", backref="applications")
    event = relationship("Event", backref="applications")


class NewsPost(Base):
    __tablename__ = "news"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(100), nullable=False)
    content = Column(Text, nullable=False)
    photo_url = Column(Text, nullable=True)
    link_url = Column(Text, nullable=True)
    author_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, server_default=func.now())

    author = relationship("User")


class Comment(Base):
    __tablename__ = "comments"
    id = Column(Integer, primary_key=True, index=True)
    news_id = Column(Integer, ForeignKey("news.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    text = Column(Text, nullable=False)
    created_at = Column(DateTime, server_default=func.now())

    author = relationship("User")


class Reaction(Base):
    __tablename__ = "reactions"
    id = Column(Integer, primary_key=True, index=True)
    news_id = Column(Integer, ForeignKey("news.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    emoji = Column(String(10), nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    __table_args__ = (UniqueConstraint("news_id", "user_id", name="_news_user_emoji_uc"),)


class FeedPost(Base):
    __tablename__ = "feed_posts"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    text = Column(Text, nullable=False)
    photo_url = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    author = relationship("User")


class TeamMember(Base):
    __tablename__ = "team_members"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    role = Column(String(120), nullable=True)
    bio = Column(Text, nullable=True)
    photo_url = Column(Text, nullable=True)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, server_default=func.now())


class SupportTicket(Base):
    __tablename__ = "support_tickets"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    subject = Column(String(150), nullable=False)
    text = Column(Text, nullable=False)
    status = Column(String(20), default="open")
    created_at = Column(DateTime, server_default=func.now())

    user = relationship("User")
    replies = relationship("SupportReply", back_populates="ticket", cascade="all, delete-orphan",
                           order_by="SupportReply.created_at")


class SupportReply(Base):
    __tablename__ = "support_replies"
    id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(Integer, ForeignKey("support_tickets.id", ondelete="CASCADE"), nullable=False)
    author_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    text = Column(Text, nullable=False)
    created_at = Column(DateTime, server_default=func.now())

    ticket = relationship("SupportTicket", back_populates="replies")
    author = relationship("User")


def user_to_dict(u: User) -> dict:
    return {
        "id": u.id,
        "login": u.login,
        "name": u.name,
        "role": u.role,
        "avatar": u.avatar,
        "full_name": u.full_name,
        "phone": u.phone,
        "age": u.age,
        "email": u.email,
    }


def event_to_dict(e: Event) -> dict:
    return {
        "id": e.id,
        "title": e.title,
        "description": e.description,
        "photo_url": e.photo_url,
        "event_date": e.event_date.isoformat(),
        "location": e.location,
        "lat": e.lat,
        "lng": e.lng,
        "category": e.category,
        "category_label": CATEGORIES.get(e.category) if e.category else None,
        "organizer_name": e.organizer.name if e.organizer else "Админ",
    }


def create_token(user_id: int, role: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=TOKEN_TTL_MINUTES)
    return jwt.encode(
        {"sub": str(user_id), "role": role, "exp": expire},
        SECRET_KEY,
        algorithm=ALGORITHM,
    )


def get_current_user(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
) -> User:
    if not authorization:
        raise HTTPException(401, "Требуется авторизация")
    try:
        token = authorization.replace("Bearer ", "")
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload.get("sub"))
    except (JWTError, ValueError, TypeError):
        raise HTTPException(401, "Неверный токен")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(401, "Пользователь не найден")
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(403, "Доступ запрещён")
    return user


LEVELS = [
    {"level": 1, "name": "Новичок", "from": 0, "to": 1},
    {"level": 2, "name": "Активист", "from": 1, "to": 3},
    {"level": 3, "name": "Подвижник", "from": 3, "to": 6},
    {"level": 4, "name": "Старший волонтёр", "from": 6, "to": 10},
    {"level": 5, "name": "Мастер", "from": 10, "to": None},
]


def compute_level(approved: int) -> dict:
    current = LEVELS[0]
    for lvl in LEVELS:
        if lvl["to"] is None or approved < lvl["to"]:
            current = lvl
            break
        current = lvl
    next_at = current["to"]
    progress = 1.0 if next_at is None else max(0.0, min(1.0, (approved - current["from"]) / (next_at - current["from"])))
    return {
        "level": current["level"],
        "name": current["name"],
        "approved": approved,
        "next_at": next_at,
        "progress": round(progress, 2),
    }


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if not db.query(User).filter(User.login == "admin").first():
            db.add(User(
                login="admin",
                password_hash=pwd_context.hash("admin1"),
                name="Админ",
                role="admin",
            ))
            db.commit()
    finally:
        db.close()
    yield


app = FastAPI(title="ПМК API", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads")
if (WEB_DIR / "assets").is_dir():
    app.mount("/assets", StaticFiles(directory=str(WEB_DIR / "assets")), name="assets")


# регистрация и вход

@app.post("/api/auth/register")
async def register(body: dict = Body(...), db: Session = Depends(get_db)):
    login_val = (body.get("login") or "").strip()
    pass_val = body.get("pass") or ""
    name_val = (body.get("name") or "").strip()

    if not login_val or not pass_val:
        raise HTTPException(422, "Заполните все поля")
    if len(pass_val) < 4:
        raise HTTPException(422, "Пароль слишком короткий")
    if db.query(User).filter(User.login == login_val).first():
        raise HTTPException(400, "Логин занят")

    db.add(User(
        login=login_val,
        password_hash=pwd_context.hash(pass_val),
        name=name_val or login_val,
    ))
    db.commit()
    return {"success": True}


@app.post("/api/auth/login")
async def login(body: dict = Body(...), db: Session = Depends(get_db)):
    login_val = body.get("login")
    pass_val = body.get("pass")
    if not login_val or not pass_val:
        raise HTTPException(422, "Логин и пароль обязательны")

    user = db.query(User).filter(User.login == login_val).first()
    if not user or not pwd_context.verify(pass_val, user.password_hash):
        raise HTTPException(401, "Неверный логин или пароль")

    return {"token": create_token(user.id, user.role), "user": user_to_dict(user)}


@app.get("/api/auth/me")
async def get_me(user: User = Depends(get_current_user)):
    return user_to_dict(user)


@app.post("/api/auth/change-password")
async def change_password(
    old_pass: str = Body(...),
    new_pass: str = Body(...),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not pwd_context.verify(old_pass, user.password_hash):
        raise HTTPException(400, "Неверный текущий пароль")
    if len(new_pass) < 4:
        raise HTTPException(422, "Новый пароль слишком короткий")
    user.password_hash = pwd_context.hash(new_pass)
    db.commit()
    return {"success": True}


# профиль

@app.get("/api/profile")
async def get_profile(user: User = Depends(get_current_user)):
    return user_to_dict(user)


@app.put("/api/profile")
async def update_profile(
    full_name: Optional[str] = Body(None),
    phone: Optional[str] = Body(None),
    age: Optional[int] = Body(None),
    email: Optional[str] = Body(None),
    avatar: Optional[str] = Body(None),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if full_name is not None:
        user.full_name = full_name
    if phone is not None:
        user.phone = phone
    if age is not None:
        user.age = age
    if email is not None:
        user.email = email
    if avatar is not None:
        user.avatar = avatar
    db.commit()
    db.refresh(user)
    return user_to_dict(user)


@app.get("/api/profile/applications")
async def my_applications(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    apps = (
        db.query(Application)
        .options(joinedload(Application.event))
        .filter(Application.user_id == user.id)
        .order_by(Application.created_at.desc())
        .all()
    )
    return [
        {
            "id": a.id,
            "event_title": a.event.title if a.event else "Мероприятие удалено",
            "event_date": a.event.event_date.isoformat() if a.event else None,
            "status": a.status or "pending",
            "message": a.message or "",
            "created_at": a.created_at.isoformat() if a.created_at else None,
        }
        for a in apps
    ]


@app.get("/api/profile/stats")
async def profile_stats(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    total = db.query(func.count(Application.id)).filter(Application.user_id == user.id).scalar() or 0
    approved = db.query(func.count(Application.id)).filter(
        Application.user_id == user.id,
        Application.status == "approved",
    ).scalar() or 0
    pending = db.query(func.count(Application.id)).filter(
        Application.user_id == user.id,
        Application.status == "pending",
    ).scalar() or 0

    return {
        "applications_total": total,
        "applications_approved": approved,
        "applications_pending": pending,
        **compute_level(approved),
    }


# уведомления

@app.get("/api/notifications")
async def notifications(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "admin":
        pending_apps = db.query(func.count(Application.id)).filter(Application.status == "pending").scalar() or 0
        open_tickets = db.query(func.count(SupportTicket.id)).filter(SupportTicket.status == "open").scalar() or 0
        return {
            "role": "admin",
            "count": int(pending_apps + open_tickets),
            "applications": int(pending_apps),
            "tickets": int(open_tickets),
        }

    apps = (
        db.query(Application)
        .options(joinedload(Application.event))
        .filter(Application.user_id == user.id, Application.status.in_(["approved", "rejected"]))
        .order_by(Application.created_at.desc())
        .limit(10)
        .all()
    )
    return {
        "role": "user",
        "count": len(apps),
        "items": [
            {
                "id": a.id,
                "event_title": a.event.title if a.event else "Мероприятие удалено",
                "status": a.status,
            }
            for a in apps
        ],
    }


# статистика и категории

@app.get("/api/stats")
async def public_stats(db: Session = Depends(get_db)):
    return {
        "volunteers": db.query(func.count(User.id)).filter(User.role == "user").scalar() or 0,
        "events": db.query(func.count(Event.id)).scalar() or 0,
        "applications_approved": db.query(func.count(Application.id))
            .filter(Application.status == "approved").scalar() or 0,
        "news": db.query(func.count(NewsPost.id)).scalar() or 0,
    }


@app.get("/api/categories")
async def list_categories():
    return [{"key": k, "label": v} for k, v in CATEGORIES.items()]


# загрузка картинок

@app.post("/api/upload")
async def upload_image(file: UploadFile = File(...), user: User = Depends(get_current_user)):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_IMAGE_EXT:
        raise HTTPException(422, "Поддерживаются PNG, JPG, WEBP, GIF")

    data = await file.read()
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Файл больше 5 МБ")

    new_name = f"{uuid.uuid4().hex}{ext}"
    target = UPLOAD_DIR / new_name
    target.write_bytes(data)
    return {"url": f"/uploads/{new_name}"}


# мероприятия

@app.get("/api/events")
async def list_events(
    search: str = Query(""),
    category: str = Query(""),
    db: Session = Depends(get_db),
):
    q = db.query(Event).options(joinedload(Event.organizer))
    if search:
        like = f"%{search}%"
        q = q.filter(Event.title.ilike(like) | Event.description.ilike(like))
    if category and category in CATEGORIES:
        q = q.filter(Event.category == category)

    events = q.order_by(Event.event_date.desc()).all()
    return [event_to_dict(e) for e in events]


@app.post("/api/admin/events")
async def create_event(
    title: str = Body(...),
    description: str = Body(""),
    event_date: str = Body(...),
    location: str = Body(""),
    photo_url: Optional[str] = Body(None),
    category: Optional[str] = Body(None),
    lat: Optional[float] = Body(None),
    lng: Optional[float] = Body(None),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    try:
        dt = datetime.fromisoformat(event_date.replace("Z", "+00:00"))
    except ValueError:
        raise HTTPException(422, "Неверный формат даты")

    if category and category not in CATEGORIES:
        raise HTTPException(422, "Неизвестная категория")

    db.add(Event(
        title=title.strip(),
        description=description.strip(),
        event_date=dt,
        location=location.strip(),
        photo_url=photo_url,
        category=category,
        lat=lat,
        lng=lng,
        organizer_id=admin.id,
    ))
    db.commit()
    return {"success": True}


@app.delete("/api/admin/events/{event_id}")
async def delete_event(
    event_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(404, "Мероприятие не найдено")
    db.delete(event)
    db.commit()
    return {"success": True}


@app.post("/api/events/{event_id}/apply")
async def apply_to_event(
    event_id: int,
    message: str = Body("", embed=True),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not db.query(Event).filter(Event.id == event_id).first():
        raise HTTPException(404, "Мероприятие не найдено")

    duplicate = db.query(Application).filter(
        Application.event_id == event_id,
        Application.user_id == user.id,
    ).first()
    if duplicate:
        raise HTTPException(400, "Вы уже подали заявку на это мероприятие")

    db.add(Application(
        event_id=event_id,
        user_id=user.id,
        message=message.strip(),
        status="pending",
    ))
    db.commit()
    return {"success": True}


# админ: заявки

@app.get("/api/admin/applications")
async def list_applications(
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    apps = (
        db.query(Application)
        .options(joinedload(Application.user), joinedload(Application.event))
        .order_by(Application.created_at.desc())
        .all()
    )
    return [
        {
            "id": a.id,
            "event_title": a.event.title if a.event else "Мероприятие удалено",
            "user_id": a.user_id,
            "user_name": (a.user.name if a.user else None) or "Аноним",
            "message": a.message or "",
            "status": a.status or "pending",
            "created_at": a.created_at.isoformat() if a.created_at else None,
        }
        for a in apps
    ]


@app.patch("/api/admin/applications/{app_id}")
async def update_application_status(
    app_id: int,
    status: str = Body(..., embed=True),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    if status not in ("approved", "rejected", "pending"):
        raise HTTPException(422, "Недопустимый статус")
    application = db.query(Application).filter(Application.id == app_id).first()
    if not application:
        raise HTTPException(404, "Заявка не найдена")
    application.status = status
    db.commit()
    return {"success": True}


@app.get("/api/admin/users/{user_id}")
async def admin_user_card(user_id: int, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    u = db.query(User).filter(User.id == user_id).first()
    if not u:
        raise HTTPException(404, "Пользователь не найден")

    total = db.query(func.count(Application.id)).filter(Application.user_id == u.id).scalar() or 0
    approved = db.query(func.count(Application.id)).filter(
        Application.user_id == u.id, Application.status == "approved",
    ).scalar() or 0

    return {
        **user_to_dict(u),
        "created_at": u.created_at.isoformat() if u.created_at else None,
        "applications_total": int(total),
        "applications_approved": int(approved),
    }


# новости

@app.get("/api/news")
async def list_news(
    search: str = Query(""),
    date: str = Query(""),
    db: Session = Depends(get_db),
):
    q = db.query(NewsPost).options(joinedload(NewsPost.author))
    if search:
        like = f"%{search}%"
        q = q.filter(NewsPost.title.ilike(like) | NewsPost.content.ilike(like))
    if date:
        q = q.filter(func.date(NewsPost.created_at) == date)

    posts = q.order_by(NewsPost.created_at.desc()).all()
    if not posts:
        return []

    reactions = (
        db.query(Reaction)
        .filter(Reaction.news_id.in_([p.id for p in posts]))
        .all()
    )
    react_by_post: dict = {}
    for r in reactions:
        bucket = react_by_post.setdefault(r.news_id, {})
        bucket[r.emoji] = bucket.get(r.emoji, 0) + 1

    return [
        {
            "id": p.id,
            "title": p.title,
            "content": p.content,
            "photo_url": p.photo_url,
            "link_url": p.link_url,
            "author_name": p.author.name if p.author else "Админ",
            "author_avatar": p.author.avatar if p.author else None,
            "created_at": p.created_at.isoformat() if p.created_at else None,
            "reactions": react_by_post.get(p.id, {}),
        }
        for p in posts
    ]


@app.post("/api/admin/news")
async def create_news(
    title: str = Body(...),
    content: str = Body(...),
    photo_url: Optional[str] = Body(None),
    link_url: Optional[str] = Body(None),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    if not title.strip() or not content.strip():
        raise HTTPException(422, "Заголовок и содержание обязательны")

    post = NewsPost(
        title=title.strip(),
        content=content.strip(),
        photo_url=photo_url,
        link_url=(link_url or None),
        author_id=admin.id,
    )
    db.add(post)
    db.commit()
    db.refresh(post)
    return {"success": True, "id": post.id}


@app.put("/api/admin/news/{news_id}")
async def update_news(
    news_id: int,
    title: str = Body(...),
    content: str = Body(...),
    photo_url: Optional[str] = Body(None),
    link_url: Optional[str] = Body(None),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    post = db.query(NewsPost).filter(NewsPost.id == news_id).first()
    if not post:
        raise HTTPException(404, "Новость не найдена")
    if not title.strip() or not content.strip():
        raise HTTPException(422, "Заголовок и содержание обязательны")

    post.title = title.strip()
    post.content = content.strip()
    post.photo_url = photo_url
    post.link_url = link_url or None
    db.commit()
    return {"success": True}


@app.delete("/api/admin/news/{news_id}")
async def delete_news(
    news_id: int,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    post = db.query(NewsPost).filter(NewsPost.id == news_id).first()
    if not post:
        raise HTTPException(404, "Новость не найдена")
    db.delete(post)
    db.commit()
    return {"success": True}


@app.post("/api/news/{news_id}/react")
async def react_news(
    news_id: int,
    emoji: str = Body(..., embed=True),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    existing = db.query(Reaction).filter(
        Reaction.news_id == news_id,
        Reaction.user_id == user.id,
    ).first()

    if existing:
        if existing.emoji == emoji:
            db.delete(existing)
        else:
            existing.emoji = emoji
    else:
        db.add(Reaction(news_id=news_id, user_id=user.id, emoji=emoji))

    db.commit()
    return {"success": True}


@app.get("/api/news/{news_id}/comments")
async def list_comments(news_id: int, db: Session = Depends(get_db)):
    comments = (
        db.query(Comment)
        .options(joinedload(Comment.author))
        .filter(Comment.news_id == news_id)
        .order_by(Comment.created_at)
        .all()
    )
    return [
        {
            "id": c.id,
            "text": c.text,
            "author_name": c.author.name if c.author else "Аноним",
            "author_avatar": c.author.avatar if c.author else None,
            "created_at": c.created_at.isoformat() if c.created_at else None,
        }
        for c in comments
    ]


@app.post("/api/news/{news_id}/comments")
async def add_comment(
    news_id: int,
    text: str = Body(..., embed=True),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not text.strip():
        raise HTTPException(422, "Комментарий не может быть пустым")
    db.add(Comment(news_id=news_id, user_id=user.id, text=text.strip()))
    db.commit()
    return {"success": True}


# лента пользовательских постов

@app.get("/api/feed")
async def list_feed(limit: int = Query(20, ge=1, le=50), db: Session = Depends(get_db)):
    posts = (
        db.query(FeedPost)
        .options(joinedload(FeedPost.author))
        .order_by(FeedPost.created_at.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "id": p.id,
            "text": p.text,
            "photo_url": p.photo_url,
            "author_id": p.user_id,
            "author_name": (p.author.name if p.author else None) or "Аноним",
            "author_avatar": p.author.avatar if p.author else None,
            "created_at": p.created_at.isoformat() if p.created_at else None,
        }
        for p in posts
    ]


@app.post("/api/feed")
async def create_feed(
    text: str = Body(...),
    photo_url: Optional[str] = Body(None),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not text.strip():
        raise HTTPException(422, "Текст не может быть пустым")
    if len(text) > 2000:
        raise HTTPException(422, "Пост слишком длинный")

    db.add(FeedPost(user_id=user.id, text=text.strip(), photo_url=photo_url))
    db.commit()
    return {"success": True}


@app.delete("/api/feed/{post_id}")
async def delete_feed(post_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    post = db.query(FeedPost).filter(FeedPost.id == post_id).first()
    if not post:
        raise HTTPException(404, "Пост не найден")
    if post.user_id != user.id and user.role != "admin":
        raise HTTPException(403, "Нельзя удалить чужой пост")
    db.delete(post)
    db.commit()
    return {"success": True}


# команда (О нас)

@app.get("/api/team")
async def list_team(db: Session = Depends(get_db)):
    members = db.query(TeamMember).order_by(TeamMember.sort_order, TeamMember.id).all()
    return [
        {
            "id": m.id,
            "name": m.name,
            "role": m.role,
            "bio": m.bio,
            "photo_url": m.photo_url,
            "sort_order": m.sort_order,
        }
        for m in members
    ]


@app.post("/api/admin/team")
async def create_team_member(
    name: str = Body(...),
    role: Optional[str] = Body(None),
    bio: Optional[str] = Body(None),
    photo_url: Optional[str] = Body(None),
    sort_order: int = Body(0),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    if not name.strip():
        raise HTTPException(422, "ФИО обязательно")
    db.add(TeamMember(
        name=name.strip(),
        role=(role or "").strip() or None,
        bio=(bio or "").strip() or None,
        photo_url=photo_url,
        sort_order=sort_order,
    ))
    db.commit()
    return {"success": True}


@app.put("/api/admin/team/{member_id}")
async def update_team_member(
    member_id: int,
    name: str = Body(...),
    role: Optional[str] = Body(None),
    bio: Optional[str] = Body(None),
    photo_url: Optional[str] = Body(None),
    sort_order: int = Body(0),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    m = db.query(TeamMember).filter(TeamMember.id == member_id).first()
    if not m:
        raise HTTPException(404, "Не найдено")
    m.name = name.strip()
    m.role = (role or "").strip() or None
    m.bio = (bio or "").strip() or None
    m.photo_url = photo_url
    m.sort_order = sort_order
    db.commit()
    return {"success": True}


@app.delete("/api/admin/team/{member_id}")
async def delete_team_member(member_id: int, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    m = db.query(TeamMember).filter(TeamMember.id == member_id).first()
    if not m:
        raise HTTPException(404, "Не найдено")
    db.delete(m)
    db.commit()
    return {"success": True}


# поддержка

def ticket_to_dict(t: SupportTicket, include_user: bool = False) -> dict:
    data = {
        "id": t.id,
        "subject": t.subject,
        "text": t.text,
        "status": t.status,
        "created_at": t.created_at.isoformat() if t.created_at else None,
        "replies": [
            {
                "id": r.id,
                "text": r.text,
                "author_name": (r.author.name if r.author else None) or "Аноним",
                "is_admin": r.author.role == "admin" if r.author else False,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in t.replies
        ],
    }
    if include_user and t.user:
        data["user_id"] = t.user.id
        data["user_name"] = t.user.name or "Аноним"
        data["user_email"] = t.user.email
    return data


@app.get("/api/support/my")
async def my_tickets(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    tickets = (
        db.query(SupportTicket)
        .options(joinedload(SupportTicket.replies).joinedload(SupportReply.author))
        .filter(SupportTicket.user_id == user.id)
        .order_by(SupportTicket.created_at.desc())
        .all()
    )
    return [ticket_to_dict(t) for t in tickets]


@app.post("/api/support")
async def create_ticket(
    subject: str = Body(...),
    text: str = Body(...),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not subject.strip() or not text.strip():
        raise HTTPException(422, "Тема и текст обязательны")
    db.add(SupportTicket(
        user_id=user.id,
        subject=subject.strip()[:150],
        text=text.strip(),
    ))
    db.commit()
    return {"success": True}


@app.get("/api/admin/support")
async def admin_tickets(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    tickets = (
        db.query(SupportTicket)
        .options(
            joinedload(SupportTicket.user),
            joinedload(SupportTicket.replies).joinedload(SupportReply.author),
        )
        .order_by(SupportTicket.created_at.desc())
        .all()
    )
    return [ticket_to_dict(t, include_user=True) for t in tickets]


@app.post("/api/admin/support/{ticket_id}/reply")
async def reply_ticket(
    ticket_id: int,
    text: str = Body(..., embed=True),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    ticket = db.query(SupportTicket).filter(SupportTicket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(404, "Обращение не найдено")
    if not text.strip():
        raise HTTPException(422, "Ответ не может быть пустым")

    db.add(SupportReply(ticket_id=ticket.id, author_id=admin.id, text=text.strip()))
    ticket.status = "answered"
    db.commit()
    return {"success": True}


@app.patch("/api/admin/support/{ticket_id}")
async def update_ticket_status(
    ticket_id: int,
    status: str = Body(..., embed=True),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    if status not in ("open", "answered", "closed"):
        raise HTTPException(422, "Недопустимый статус")
    ticket = db.query(SupportTicket).filter(SupportTicket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(404, "Не найдено")
    ticket.status = status
    db.commit()
    return {"success": True}


@app.get("/{full_path:path}")
async def spa_fallback(full_path: str):
    if full_path.startswith(("api/", "uploads/", "assets/")):
        raise HTTPException(404)

    target = WEB_DIR / full_path
    if target.is_file():
        return FileResponse(target)

    index = WEB_DIR / "index.html"
    if index.is_file():
        return FileResponse(index)
    raise HTTPException(404)


def run_app():
    import threading
    import time
    import webbrowser
    import uvicorn

    def open_browser():
        time.sleep(1.5)
        try:
            webbrowser.open("http://localhost:8000")
        except Exception:
            pass

    threading.Thread(target=open_browser, daemon=True).start()
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")


if __name__ == "__main__":
    run_app()

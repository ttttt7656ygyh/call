import os
import sys

from dotenv import load_dotenv

sys.path.append(os.path.dirname(__file__))

from server import Base, SessionLocal, User, engine, pwd_context


load_dotenv()


def main(login: str = "admin", password: str = "admin1") -> None:
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        removed = db.query(User).filter(User.login == login).delete()
        db.add(User(
            login=login,
            password_hash=pwd_context.hash(password),
            name="Админ",
            role="admin",
        ))
        db.commit()
        print(f"Удалено старых записей: {removed}")
        print(f"Создан администратор {login} / {password}")
    finally:
        db.close()


if __name__ == "__main__":
    main()

import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const checkAuth = useCallback(async () => {
    const token = localStorage.getItem('pmk_token');
    if (!token) {
      setLoading(false);
      return;
    }
    try {
      const { data } = await api.get('/auth/me');
      setUser(data);
    } catch {
      localStorage.removeItem('pmk_token');
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const login = async (login, pass) => {
    const { data } = await api.post('/auth/login', { login, pass });
    localStorage.setItem('pmk_token', data.token);
    setUser(data.user);
    return data.user;
  };

  const register = async (name, login, pass) => {
    await api.post('/auth/register', { name, login, pass });
  };

  const logout = () => {
    localStorage.removeItem('pmk_token');
    setUser(null);
  };

  const updateProfile = async (profileData) => {
    const { data } = await api.put('/profile', profileData);
    setUser((prev) => (prev ? { ...prev, ...data } : null));
    return data;
  };

  useEffect(() => {
    checkAuth();
    window.addEventListener('auth:logout', checkAuth);
    return () => window.removeEventListener('auth:logout', checkAuth);
  }, [checkAuth]);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateProfile, refresh: checkAuth }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

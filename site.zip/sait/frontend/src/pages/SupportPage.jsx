import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api/client';

const STATUS_LABELS = {
  open: 'Открыто',
  answered: 'Есть ответ',
  closed: 'Закрыто',
};

function formatDateTime(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleString('ru-RU', {
    day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

export default function SupportPage() {
  const { user } = useAuth();
  const [tickets, setTickets] = useState(null);
  const [form, setForm] = useState({ subject: '', text: '' });
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(null);

  const load = () => {
    if (!user) {
      setTickets([]);
      return;
    }
    api.get('/support/my').then((res) => setTickets(res.data)).catch(() => setTickets([]));
  };

  useEffect(load, [user]);

  const submit = async (e) => {
    e.preventDefault();
    if (!form.subject.trim() || !form.text.trim()) return;
    setBusy(true);
    try {
      await api.post('/support', { subject: form.subject, text: form.text });
      setForm({ subject: '', text: '' });
      setMessage({ type: 'success', text: 'Обращение отправлено' });
      load();
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось отправить' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="static-page">
      <div className="card">
        <h2>Поддержка</h2>
        <p>
          Если у вас возникли вопросы по работе сайта или вы хотите предложить
          сотрудничество — напишите нам. Мы постараемся ответить в течение нескольких дней.
        </p>
      </div>

      <div className="card">
        <h3>Контакты</h3>
        <ul className="bullet-list">
          <li>Электронная почта: <a href="mailto:pmk-kemerovo@example.ru">pmk-kemerovo@example.ru</a></li>
          <li>Телефон: +7 (3842) 00-00-00</li>
          <li>Адрес: г. Кемерово, Знаменский собор</li>
        </ul>
      </div>

      {message && (
        <div className={`alert ${message.type}`} onClick={() => setMessage(null)}>
          {message.text}
        </div>
      )}

      <div className="section-title">
        <h2>Написать обращение</h2>
      </div>

      {user ? (
        <form className="card" onSubmit={submit}>
          <div className="form-group">
            <label>Тема</label>
            <input
              type="text"
              className="form-input"
              maxLength="150"
              value={form.subject}
              onChange={(e) => setForm({ ...form, subject: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>Текст обращения</label>
            <textarea
              className="form-input"
              rows="5"
              value={form.text}
              onChange={(e) => setForm({ ...form, text: e.target.value })}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary" disabled={busy}>
            {busy ? 'Отправка...' : 'Отправить'}
          </button>
        </form>
      ) : (
        <div className="card">
          <p className="hint">Чтобы оставить обращение, войдите в аккаунт.</p>
        </div>
      )}

      {user && (
        <>
          <div className="section-title">
            <h2>Мои обращения</h2>
          </div>

          {tickets === null ? (
            <p className="hint">Загрузка...</p>
          ) : tickets.length === 0 ? (
            <div className="card">
              <p className="hint">У вас пока нет обращений.</p>
            </div>
          ) : (
            <div className="tickets-list">
              {tickets.map((t) => (
                <div key={t.id} className="card ticket-card">
                  <div className="ticket-head">
                    <div>
                      <div className="ticket-subject">{t.subject}</div>
                      <div className="ticket-meta">{formatDateTime(t.created_at)}</div>
                    </div>
                    <span className={`badge badge-${t.status}`}>
                      {STATUS_LABELS[t.status] || t.status}
                    </span>
                  </div>

                  <div className="ticket-text">{t.text}</div>

                  {t.replies.length > 0 && (
                    <div className="ticket-replies">
                      {t.replies.map((r) => (
                        <div key={r.id} className={`ticket-reply ${r.is_admin ? 'from-admin' : ''}`}>
                          <div className="ticket-reply-author">
                            {r.author_name} {r.is_admin && '(админ)'}
                            <span className="ticket-meta" style={{ marginLeft: 8 }}>
                              {formatDateTime(r.created_at)}
                            </span>
                          </div>
                          <div style={{ whiteSpace: 'pre-wrap' }}>{r.text}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </section>
  );
}

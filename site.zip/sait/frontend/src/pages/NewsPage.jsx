import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api/client';
import ImageUpload from '../components/ImageUpload';
import { SkeletonCard } from '../components/Skeleton';
import FadeIn from '../components/FadeIn';

const REACTIONS = ['❤️', '👍', '🙏'];
const EMPTY_FORM = { title: '', content: '', photo_url: '', link_url: '' };

function formatDateTime(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleString('ru-RU', {
    day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

export default function NewsPage() {
  const { user } = useAuth();
  const [news, setNews] = useState(null);
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [formMode, setFormMode] = useState(null); // null | 'create' | 'edit'
  const [editId, setEditId] = useState(null);
  const [draft, setDraft] = useState(EMPTY_FORM);
  const [openComments, setOpenComments] = useState({});
  const [comments, setComments] = useState({});
  const [commentText, setCommentText] = useState({});
  const [pageMessage, setPageMessage] = useState(null);

  const loadNews = async () => {
    setNews(null);
    try {
      const qs = new URLSearchParams();
      if (search) qs.append('search', search);
      if (dateFilter) qs.append('date', dateFilter);
      const { data } = await api.get(`/news?${qs}`);
      setNews(data);
    } catch {
      setNews([]);
      setPageMessage({ type: 'error', text: 'Не удалось загрузить новости' });
    }
  };

  useEffect(() => {
    const id = setTimeout(loadNews, 300);
    return () => clearTimeout(id);
  }, [search, dateFilter]);

  const toggleComments = async (newsId) => {
    const next = !openComments[newsId];
    setOpenComments({ ...openComments, [newsId]: next });
    if (next && !comments[newsId]) {
      try {
        const { data } = await api.get(`/news/${newsId}/comments`);
        setComments((prev) => ({ ...prev, [newsId]: data }));
      } catch {
        setComments((prev) => ({ ...prev, [newsId]: [] }));
      }
    }
  };

  const startCreate = () => {
    setFormMode('create');
    setEditId(null);
    setDraft(EMPTY_FORM);
  };

  const startEdit = (item) => {
    setFormMode('edit');
    setEditId(item.id);
    setDraft({
      title: item.title || '',
      content: item.content || '',
      photo_url: item.photo_url || '',
      link_url: item.link_url || '',
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const cancelForm = () => {
    setFormMode(null);
    setEditId(null);
    setDraft(EMPTY_FORM);
  };

  const submitForm = async (e) => {
    e.preventDefault();
    const payload = {
      title: draft.title,
      content: draft.content,
      photo_url: draft.photo_url || null,
      link_url: draft.link_url || null,
    };
    try {
      if (formMode === 'edit') {
        await api.put(`/admin/news/${editId}`, payload);
        setPageMessage({ type: 'success', text: 'Новость обновлена' });
      } else {
        await api.post('/admin/news', payload);
        setPageMessage({ type: 'success', text: 'Новость опубликована' });
      }
      cancelForm();
      loadNews();
    } catch (err) {
      setPageMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось сохранить' });
    }
  };

  const handleDeleteNews = async (newsId, title) => {
    if (!window.confirm(`Удалить новость «${title}»?`)) return;
    try {
      await api.delete(`/admin/news/${newsId}`);
      setNews((prev) => prev.filter((n) => n.id !== newsId));
      setPageMessage({ type: 'success', text: 'Новость удалена' });
    } catch (err) {
      setPageMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось удалить' });
    }
  };

  const handleReact = async (newsId, emoji) => {
    if (!user) {
      setPageMessage({ type: 'error', text: 'Войдите, чтобы поставить реакцию' });
      return;
    }
    try {
      await api.post(`/news/${newsId}/react`, { emoji });
      loadNews();
    } catch {
      setPageMessage({ type: 'error', text: 'Не удалось сохранить реакцию' });
    }
  };

  const handleAddComment = async (newsId) => {
    if (!user) {
      setPageMessage({ type: 'error', text: 'Войдите, чтобы оставить комментарий' });
      return;
    }
    const text = commentText[newsId]?.trim();
    if (!text) return;
    try {
      await api.post(`/news/${newsId}/comments`, { text });
      setCommentText({ ...commentText, [newsId]: '' });
      const { data } = await api.get(`/news/${newsId}/comments`);
      setComments((prev) => ({ ...prev, [newsId]: data }));
    } catch (err) {
      setPageMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось отправить' });
    }
  };

  return (
    <div className="news-page">
      <div className="page-head">
        <h1>Новости</h1>
        {user?.role === 'admin' && formMode === null && (
          <button className="btn btn-primary" onClick={startCreate}>Создать новость</button>
        )}
      </div>

      {pageMessage && (
        <div className={`alert ${pageMessage.type}`} onClick={() => setPageMessage(null)}>
          {pageMessage.text}
        </div>
      )}

      <div className="events-search" style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 18 }}>
        <input
          type="text"
          className="form-input"
          placeholder="Поиск по названию или содержанию"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ margin: 0, flex: 1, minWidth: 200 }}
        />
        <input
          type="date"
          className="form-input"
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
          style={{ margin: 0, width: 180 }}
        />
      </div>

      {formMode && (
        <form onSubmit={submitForm} className="card">
          <h2 style={{ marginBottom: '1rem' }}>
            {formMode === 'edit' ? 'Редактирование новости' : 'Новая новость'}
          </h2>
          <div className="form-group">
            <label>Заголовок</label>
            <input
              type="text"
              className="form-input"
              value={draft.title}
              onChange={(e) => setDraft({ ...draft, title: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>Содержание</label>
            <textarea
              className="form-input"
              rows="6"
              value={draft.content}
              onChange={(e) => setDraft({ ...draft, content: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>Ссылка (например, на видео-отчёт)</label>
            <input
              type="url"
              className="form-input"
              placeholder="https://..."
              value={draft.link_url}
              onChange={(e) => setDraft({ ...draft, link_url: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Фото</label>
            <ImageUpload
              value={draft.photo_url}
              onChange={(url) => setDraft({ ...draft, photo_url: url })}
            />
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="submit" className="btn btn-primary">
              {formMode === 'edit' ? 'Сохранить' : 'Опубликовать'}
            </button>
            <button type="button" className="btn btn-outline" onClick={cancelForm}>Отмена</button>
          </div>
        </form>
      )}

      {news === null ? (
        <>
          <SkeletonCard />
          <SkeletonCard />
        </>
      ) : news.length === 0 ? (
        <div className="card news-empty">
          <p>Пока новостей нет</p>
          <p className="hint">Загляните позже</p>
        </div>
      ) : (
        <div className="news-list">
          {news.map((item, i) => (
            <FadeIn key={item.id} delay={i * 60} as="article" className="card news-item">
              {item.photo_url && <img src={item.photo_url} alt={item.title} className="news-photo" />}

              <div className="news-title-row">
                <h3 className="news-title">{item.title}</h3>
                {user?.role === 'admin' && (
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button className="btn btn-sm btn-outline" onClick={() => startEdit(item)}>
                      Изменить
                    </button>
                    <button className="btn btn-sm btn-danger" onClick={() => handleDeleteNews(item.id, item.title)}>
                      Удалить
                    </button>
                  </div>
                )}
              </div>

              <div className="news-meta">
                <span className="news-author">{item.author_name}</span>
                <span className="news-date">{formatDateTime(item.created_at)}</span>
              </div>

              <p className="news-text">{item.content}</p>

              {item.link_url && (
                <p style={{ marginBottom: '1rem' }}>
                  <a href={item.link_url} target="_blank" rel="noopener noreferrer">
                    Перейти по ссылке →
                  </a>
                </p>
              )}

              <div className="news-reactions">
                {item.reactions && Object.entries(item.reactions).map(([emoji, count]) => (
                  <span key={emoji} className="reaction-badge">{emoji} {count}</span>
                ))}
                {REACTIONS.map((emoji) => (
                  <button
                    key={emoji}
                    className="btn btn-sm btn-ghost"
                    onClick={() => handleReact(item.id, emoji)}
                  >
                    {emoji}
                  </button>
                ))}
              </div>

              <div className="news-comments">
                <button className="btn btn-sm btn-ghost" onClick={() => toggleComments(item.id)}>
                  {openComments[item.id] ? 'Скрыть комментарии' : 'Показать комментарии'}
                </button>

                {openComments[item.id] && (
                  <>
                    <div className="comments-list">
                      {(comments[item.id] || []).map((c) => (
                        <div key={c.id} className="comment-item">
                          <strong>{c.author_name}</strong>
                          <span className="comment-date">{formatDateTime(c.created_at)}</span>
                          <p>{c.text}</p>
                        </div>
                      ))}
                      {comments[item.id]?.length === 0 && (
                        <p className="hint">Комментариев пока нет</p>
                      )}
                    </div>

                    {user && (
                      <div className="comment-form">
                        <input
                          type="text"
                          className="form-input"
                          placeholder="Написать комментарий..."
                          value={commentText[item.id] || ''}
                          onChange={(e) => setCommentText({ ...commentText, [item.id]: e.target.value })}
                        />
                        <button className="btn btn-primary btn-sm" onClick={() => handleAddComment(item.id)}>
                          Отправить
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </FadeIn>
          ))}
        </div>
      )}
    </div>
  );
}

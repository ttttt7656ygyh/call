import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api/client';
import ImageUpload from '../components/ImageUpload';

const EMPTY = { name: '', role: '', bio: '', photo_url: '', sort_order: 0 };

export default function AboutPage() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const [members, setMembers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [draft, setDraft] = useState(EMPTY);
  const [editId, setEditId] = useState(null);
  const [message, setMessage] = useState(null);

  const load = () => {
    api.get('/team').then((res) => setMembers(res.data)).catch(() => setMembers([]));
  };

  useEffect(load, []);

  const startCreate = () => {
    setShowForm(true);
    setEditId(null);
    setDraft(EMPTY);
  };

  const startEdit = (m) => {
    setShowForm(true);
    setEditId(m.id);
    setDraft({
      name: m.name || '',
      role: m.role || '',
      bio: m.bio || '',
      photo_url: m.photo_url || '',
      sort_order: m.sort_order || 0,
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const cancel = () => {
    setShowForm(false);
    setEditId(null);
    setDraft(EMPTY);
  };

  const submit = async (e) => {
    e.preventDefault();
    try {
      const body = {
        name: draft.name,
        role: draft.role || null,
        bio: draft.bio || null,
        photo_url: draft.photo_url || null,
        sort_order: Number(draft.sort_order) || 0,
      };
      if (editId) {
        await api.put(`/admin/team/${editId}`, body);
      } else {
        await api.post('/admin/team', body);
      }
      cancel();
      load();
      setMessage({ type: 'success', text: 'Сохранено' });
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось сохранить' });
    }
  };

  const remove = async (id, name) => {
    if (!window.confirm(`Удалить «${name}»?`)) return;
    try {
      await api.delete(`/admin/team/${id}`);
      setMembers((prev) => prev.filter((m) => m.id !== id));
      setMessage({ type: 'success', text: 'Удалено' });
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось удалить' });
    }
  };

  return (
    <section className="static-page">
      <div className="card">
        <h2>О нас</h2>
        <p>
          Православная Молодёжь Кемерово объединяет волонтёров при Знаменском соборе.
          Мы помогаем храму, проводим благотворительные акции, организуем встречи,
          поездки и просветительские мероприятия.
        </p>
      </div>

      <div className="card">
        <h3>Наши направления</h3>
        <ul className="bullet-list">
          <li>Социальное служение — помощь нуждающимся, посещение домов престарелых.</li>
          <li>Просветительство — встречи со священниками, лекции, кинопросмотры.</li>
          <li>Творчество — концерты, фестивали, рукоделие.</li>
          <li>Паломничества — поездки по святым местам Кузбасса и Сибири.</li>
        </ul>
      </div>

      <div className="section-title">
        <h2>Совет православной молодёжи Кемерово</h2>
      </div>

      {message && (
        <div className={`alert ${message.type}`} onClick={() => setMessage(null)}>
          {message.text}
        </div>
      )}

      {isAdmin && !showForm && (
        <div style={{ marginBottom: '1rem' }}>
          <button className="btn btn-primary" onClick={startCreate}>Добавить участника</button>
        </div>
      )}

      {isAdmin && showForm && (
        <form className="card" onSubmit={submit}>
          <h3 style={{ marginBottom: '1rem' }}>
            {editId ? 'Редактирование участника' : 'Новый участник'}
          </h3>
          <div className="form-group">
            <label>ФИО *</label>
            <input
              type="text"
              className="form-input"
              value={draft.name}
              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>Должность / роль</label>
            <input
              type="text"
              className="form-input"
              placeholder="Председатель, координатор и т.д."
              value={draft.role}
              onChange={(e) => setDraft({ ...draft, role: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>О себе</label>
            <textarea
              className="form-input"
              rows="4"
              value={draft.bio}
              onChange={(e) => setDraft({ ...draft, bio: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Порядок отображения (меньше = выше)</label>
            <input
              type="number"
              className="form-input"
              value={draft.sort_order}
              onChange={(e) => setDraft({ ...draft, sort_order: e.target.value })}
              style={{ maxWidth: 120 }}
            />
          </div>
          <div className="form-group">
            <label>Фотография</label>
            <ImageUpload
              value={draft.photo_url}
              onChange={(url) => setDraft({ ...draft, photo_url: url })}
            />
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="submit" className="btn btn-primary">Сохранить</button>
            <button type="button" className="btn btn-outline" onClick={cancel}>Отмена</button>
          </div>
        </form>
      )}

      {members.length === 0 ? (
        <div className="card">
          <p className="hint">
            {isAdmin
              ? 'Список пока пуст. Добавьте первого участника команды.'
              : 'Информация о команде скоро появится.'}
          </p>
        </div>
      ) : (
        <div className="team-grid">
          {members.map((m) => (
            <div key={m.id} className="team-card">
              {m.photo_url ? (
                <img src={m.photo_url} alt={m.name} className="team-photo" />
              ) : (
                <div className="team-photo placeholder">{m.name[0]}</div>
              )}
              <div className="team-name">{m.name}</div>
              {m.role && <div className="team-role">{m.role}</div>}
              {m.bio && <p className="team-bio">{m.bio}</p>}

              {isAdmin && (
                <div className="team-controls">
                  <button className="btn btn-sm btn-outline" onClick={() => startEdit(m)}>
                    Изменить
                  </button>
                  <button className="btn btn-sm btn-danger" onClick={() => remove(m.id, m.name)}>
                    Удалить
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

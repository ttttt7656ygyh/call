import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api/client';
import AdminApplications from '../components/AdminApplications';

const STATUS_LABELS = {
  pending: 'Ожидает',
  approved: 'Одобрено',
  rejected: 'Отклонено',
};

function formatDateTime(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleString('ru-RU', {
    day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

export default function ProfilePage() {
  const { user, updateProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);

  const [formData, setFormData] = useState({
    full_name: '', phone: '', age: '', email: '', avatar: '',
  });
  const [passData, setPassData] = useState({ old_pass: '', new_pass: '', confirm_pass: '' });

  const [myApps, setMyApps] = useState(null);
  const [stats, setStats] = useState(null);

  useEffect(() => {
    if (user) {
      setFormData({
        full_name: user.full_name || '',
        phone: user.phone || '',
        age: user.age || '',
        email: user.email || '',
        avatar: user.avatar || '',
      });
    }
  }, [user]);

  useEffect(() => {
    if (activeTab === 'activity' && user?.role !== 'admin') {
      if (myApps === null) {
        api.get('/profile/applications').then((res) => setMyApps(res.data)).catch(() => setMyApps([]));
      }
      if (stats === null) {
        api.get('/profile/stats').then((res) => setStats(res.data)).catch(() => {});
      }
    }
  }, [activeTab, user, myApps, stats]);

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    try {
      await updateProfile({
        ...formData,
        age: formData.age ? parseInt(formData.age, 10) : null,
      });
      setMessage({ type: 'success', text: 'Данные сохранены' });
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось сохранить' });
    } finally {
      setLoading(false);
    }
  };

  const handlePassSubmit = async (e) => {
    e.preventDefault();
    setMessage(null);
    if (passData.new_pass !== passData.confirm_pass) {
      setMessage({ type: 'error', text: 'Пароли не совпадают' });
      return;
    }
    setLoading(true);
    try {
      await api.post('/auth/change-password', {
        old_pass: passData.old_pass,
        new_pass: passData.new_pass,
      });
      setMessage({ type: 'success', text: 'Пароль изменён' });
      setPassData({ old_pass: '', new_pass: '', confirm_pass: '' });
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось сменить пароль' });
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="profile-container">
      <aside className="profile-sidebar">
        <div className="card" style={{ padding: '1.4rem' }}>
          <div className="profile-header">
            {user.avatar ? (
              <img src={user.avatar} alt="" className="profile-avatar" />
            ) : (
              <div className="profile-avatar placeholder">{(user.name || user.login || '?')[0]}</div>
            )}
            <h3>{user.full_name || user.name}</h3>
            <p className="profile-role">{user.role === 'admin' ? 'Администратор' : 'Волонтёр'}</p>
          </div>

          <nav className="profile-nav">
            <button className={activeTab === 'profile' ? 'active' : ''} onClick={() => setActiveTab('profile')}>
              Личные данные
            </button>
            <button className={activeTab === 'security' ? 'active' : ''} onClick={() => setActiveTab('security')}>
              Безопасность
            </button>
            <button className={activeTab === 'activity' ? 'active' : ''} onClick={() => setActiveTab('activity')}>
              Активность
            </button>
          </nav>
        </div>
      </aside>

      <main className="profile-content">
        {message && (
          <div className={`alert ${message.type}`} onClick={() => setMessage(null)}>
            {message.text}
          </div>
        )}

        {activeTab === 'profile' && (
          <form onSubmit={handleProfileSubmit} className="card profile-form">
            <h2>Личные данные</h2>
            <div className="form-group">
              <label>ФИО</label>
              <input
                type="text"
                value={formData.full_name}
                onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                className="form-input"
              />
            </div>
            <div className="form-group">
              <label>Телефон</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="form-input"
                placeholder="+7 (999) 123-45-67"
              />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label>Возраст</label>
                <input
                  type="number"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  className="form-input"
                  min="14"
                  max="120"
                />
              </div>
              <div className="form-group">
                <label>Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="form-input"
                />
              </div>
            </div>
            <div className="form-group">
              <label>Ссылка на аватар</label>
              <input
                type="text"
                value={formData.avatar}
                onChange={(e) => setFormData({ ...formData, avatar: e.target.value })}
                className="form-input"
                placeholder="https://..."
              />
            </div>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Сохранение...' : 'Сохранить'}
            </button>
          </form>
        )}

        {activeTab === 'security' && (
          <form onSubmit={handlePassSubmit} className="card profile-form">
            <h2>Смена пароля</h2>
            <div className="form-group">
              <label>Текущий пароль</label>
              <input
                type="password"
                value={passData.old_pass}
                onChange={(e) => setPassData({ ...passData, old_pass: e.target.value })}
                className="form-input"
                required
              />
            </div>
            <div className="form-group">
              <label>Новый пароль</label>
              <input
                type="password"
                value={passData.new_pass}
                onChange={(e) => setPassData({ ...passData, new_pass: e.target.value })}
                className="form-input"
                required
                minLength="4"
              />
            </div>
            <div className="form-group">
              <label>Подтвердите пароль</label>
              <input
                type="password"
                value={passData.confirm_pass}
                onChange={(e) => setPassData({ ...passData, confirm_pass: e.target.value })}
                className="form-input"
                required
              />
            </div>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Обновление...' : 'Сменить пароль'}
            </button>
          </form>
        )}

        {activeTab === 'activity' && (
          <div className="card profile-form">
            <h2>Ваша активность</h2>

            {user.role === 'admin' ? (
              <AdminApplications />
            ) : (
              <>
                {stats && (
                  <div className="gamification">
                    <div className="level-badge"><span>{stats.level}</span></div>
                    <div className="level-info">
                      <h3>{stats.name}</h3>
                      <div className="level-sub">
                        {stats.next_at
                          ? `${stats.approved} из ${stats.next_at} одобренных заявок до следующего уровня`
                          : 'Высший уровень достигнут'}
                      </div>
                      <div className="progress-bar">
                        <div style={{ width: `${Math.round(stats.progress * 100)}%` }} />
                      </div>
                      <div className="hint" style={{ marginTop: 10 }}>
                        Всего заявок: {stats.applications_total} · Одобрено: {stats.applications_approved} · Ожидают: {stats.applications_pending}
                      </div>
                    </div>
                  </div>
                )}

                <div className="card-divider" />

                <h3 style={{ marginBottom: '1rem' }}>Мои заявки</h3>

                {myApps === null ? (
                  <p className="hint">Загрузка...</p>
                ) : myApps.length === 0 ? (
                  <p className="hint">Пока нет заявок. Загляните в раздел «Мероприятия».</p>
                ) : (
                  <div className="activity-list">
                    {myApps.map((a) => (
                      <div key={a.id} className="activity-item">
                        <div>
                          <div className="activity-title">{a.event_title}</div>
                          {a.event_date && (
                            <div className="activity-meta">{formatDateTime(a.event_date)}</div>
                          )}
                        </div>
                        <span className={`badge badge-${a.status}`}>
                          {STATUS_LABELS[a.status] || a.status}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api/client';
import CategoryChips from '../components/CategoryChips';
import ImageUpload from '../components/ImageUpload';
import { EventsMap, LocationPicker } from '../components/EventsMap';
import EventsCalendar from '../components/EventsCalendar';
import { SkeletonCard } from '../components/Skeleton';
import FadeIn from '../components/FadeIn';
import { IconList, IconMap, IconCalendar } from '../components/Icons';

function formatDateTime(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleString('ru-RU', {
    day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

export default function EventsPage() {
  const { user } = useAuth();
  const [events, setEvents] = useState(null);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [view, setView] = useState('list');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [message, setMessage] = useState(null);
  const [applyTo, setApplyTo] = useState(null);
  const [applyText, setApplyText] = useState('');
  const [categories, setCategories] = useState([]);

  const [eventForm, setEventForm] = useState({
    title: '',
    description: '',
    event_date: '',
    location: '',
    photo_url: '',
    category: '',
    point: null,
  });

  useEffect(() => {
    api.get('/categories').then((res) => setCategories(res.data)).catch(() => {});
  }, []);

  const loadEvents = async () => {
    setEvents(null);
    try {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (category) params.append('category', category);
      const { data } = await api.get(`/events?${params}`);
      setEvents(data);
    } catch {
      setEvents([]);
      setMessage({ type: 'error', text: 'Не удалось загрузить мероприятия' });
    }
  };

  useEffect(() => {
    const id = setTimeout(loadEvents, 300);
    return () => clearTimeout(id);
  }, [search, category]);

  const handleCreateEvent = async (e) => {
    e.preventDefault();
    try {
      await api.post('/admin/events', {
        title: eventForm.title,
        description: eventForm.description,
        event_date: new Date(eventForm.event_date).toISOString(),
        location: eventForm.location,
        photo_url: eventForm.photo_url || null,
        category: eventForm.category || null,
        lat: eventForm.point?.lat || null,
        lng: eventForm.point?.lng || null,
      });
      setEventForm({
        title: '', description: '', event_date: '', location: '',
        photo_url: '', category: '', point: null,
      });
      setShowCreateForm(false);
      setMessage({ type: 'success', text: 'Мероприятие создано' });
      loadEvents();
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось создать' });
    }
  };

  const handleDeleteEvent = async (id, title) => {
    if (!window.confirm(`Удалить мероприятие «${title}»?`)) return;
    try {
      await api.delete(`/admin/events/${id}`);
      setEvents((prev) => prev.filter((e) => e.id !== id));
      setMessage({ type: 'success', text: 'Мероприятие удалено' });
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось удалить' });
    }
  };

  const openApply = (event) => {
    if (!user) {
      setMessage({ type: 'error', text: 'Войдите, чтобы подать заявку' });
      return;
    }
    setApplyTo(event);
    setApplyText('');
  };

  const submitApply = async (e) => {
    e.preventDefault();
    try {
      await api.post(`/events/${applyTo.id}/apply`, { message: applyText });
      setApplyTo(null);
      setMessage({ type: 'success', text: 'Заявка отправлена, ожидайте подтверждения' });
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.detail || 'Не удалось отправить' });
    }
  };

  return (
    <div className="events-page">
      <div className="page-head">
        <h1>Мероприятия</h1>
        {user?.role === 'admin' && (
          <button className="btn btn-primary" onClick={() => setShowCreateForm(!showCreateForm)}>
            {showCreateForm ? 'Отмена' : 'Создать мероприятие'}
          </button>
        )}
      </div>

      <div className="events-search">
        <input
          type="text"
          className="form-input"
          placeholder="Поиск мероприятий"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ margin: 0 }}
        />
      </div>

      {categories.length > 0 && (
        <CategoryChips categories={categories} value={category} onChange={setCategory} />
      )}

      <div className="view-tabs">
        <button className={view === 'list' ? 'active' : ''} onClick={() => setView('list')}>
          <IconList size={14} /> Список
        </button>
        <button className={view === 'calendar' ? 'active' : ''} onClick={() => setView('calendar')}>
          <IconCalendar size={14} /> Календарь
        </button>
        <button className={view === 'map' ? 'active' : ''} onClick={() => setView('map')}>
          <IconMap size={14} /> Карта
        </button>
      </div>

      {message && (
        <div className={`alert ${message.type}`} onClick={() => setMessage(null)}>
          {message.text}
        </div>
      )}

      {showCreateForm && user?.role === 'admin' && (
        <form onSubmit={handleCreateEvent} className="card">
          <h2 style={{ marginBottom: '1rem' }}>Новое мероприятие</h2>

          <div className="form-group">
            <label>Название *</label>
            <input
              type="text"
              className="form-input"
              value={eventForm.title}
              onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label>Категория</label>
            <select
              className="form-input"
              value={eventForm.category}
              onChange={(e) => setEventForm({ ...eventForm, category: e.target.value })}
            >
              <option value="">Без категории</option>
              {categories.map((c) => (
                <option key={c.key} value={c.key}>{c.label}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Описание</label>
            <textarea
              className="form-input"
              rows="3"
              value={eventForm.description}
              onChange={(e) => setEventForm({ ...eventForm, description: e.target.value })}
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Дата и время *</label>
              <input
                type="datetime-local"
                className="form-input"
                value={eventForm.event_date}
                onChange={(e) => setEventForm({ ...eventForm, event_date: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Место</label>
              <input
                type="text"
                className="form-input"
                value={eventForm.location}
                onChange={(e) => setEventForm({ ...eventForm, location: e.target.value })}
                placeholder="Центральный парк"
              />
            </div>
          </div>

          <div className="form-group">
            <label>Точка на карте (нажмите для выбора)</label>
            <LocationPicker
              value={eventForm.point}
              onChange={(pt) => setEventForm({ ...eventForm, point: pt })}
            />
            {eventForm.point && (
              <p className="hint" style={{ marginTop: 6 }}>
                {eventForm.point.lat.toFixed(4)}, {eventForm.point.lng.toFixed(4)}
              </p>
            )}
          </div>

          <div className="form-group">
            <label>Фото</label>
            <ImageUpload
              value={eventForm.photo_url}
              onChange={(url) => setEventForm({ ...eventForm, photo_url: url })}
            />
          </div>

          <button type="submit" className="btn btn-primary">Создать</button>
        </form>
      )}

      {events === null ? (
        <>
          <SkeletonCard />
          <SkeletonCard />
        </>
      ) : view === 'calendar' ? (
        <FadeIn><EventsCalendar events={events} /></FadeIn>
      ) : view === 'map' ? (
        <FadeIn><EventsMap events={events} /></FadeIn>
      ) : events.length === 0 ? (
        <div className="card events-empty">
          <p>По вашему запросу ничего не найдено</p>
          <p className="hint">
            {user?.role === 'admin' ? 'Создайте первое мероприятие' : 'Загляните позже'}
          </p>
        </div>
      ) : (
        <div className="events-list">
          {events.map((event, i) => (
            <FadeIn key={event.id} delay={i * 60} as="article" className="card event-item">
              {event.photo_url && (
                <img src={event.photo_url} alt={event.title} className="event-photo" />
              )}

              <div className="event-title-row">
                <div>
                  <h3 className="event-title">{event.title}</h3>
                  {event.category_label && (
                    <span className="badge" style={{ background: 'var(--accent-soft)', color: 'var(--primary)' }}>
                      {event.category_label}
                    </span>
                  )}
                </div>
                {user?.role === 'admin' && (
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => handleDeleteEvent(event.id, event.title)}
                  >
                    Удалить
                  </button>
                )}
              </div>

              {event.description && <p className="event-description">{event.description}</p>}

              <div className="event-meta">
                <div className="event-meta-item">
                  <span className="event-meta-label">Когда:</span>
                  <span>{formatDateTime(event.event_date)}</span>
                </div>
                {event.location && (
                  <div className="event-meta-item">
                    <span className="event-meta-label">Где:</span>
                    <span>{event.location}</span>
                  </div>
                )}
                <div className="event-meta-item">
                  <span className="event-meta-label">Организатор:</span>
                  <span>{event.organizer_name || 'Админ'}</span>
                </div>
              </div>

              {user ? (
                <button className="btn btn-primary event-apply-btn" onClick={() => openApply(event)}>
                  Подать заявку
                </button>
              ) : (
                <p className="hint center">Войдите, чтобы подать заявку</p>
              )}
            </FadeIn>
          ))}
        </div>
      )}

      {applyTo && (
        <div className="modal" onClick={() => setApplyTo(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h3 className="modal-title">Заявка на «{applyTo.title}»</h3>
            <form onSubmit={submitApply}>
              <label>Сообщение организатору (необязательно)</label>
              <textarea
                className="form-input"
                rows="4"
                value={applyText}
                onChange={(e) => setApplyText(e.target.value)}
                placeholder="Расскажите немного о себе"
              />
              <button type="submit" className="btn btn-primary btn-block">Отправить</button>
              <button type="button" className="btn btn-outline btn-block" onClick={() => setApplyTo(null)}>
                Отмена
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

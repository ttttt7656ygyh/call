import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';
import AnimatedCounter from '../components/AnimatedCounter';
import FadeIn from '../components/FadeIn';
import { SkeletonCard } from '../components/Skeleton';
import FeedSection from '../components/FeedSection';

function formatDate(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleDateString('ru-RU', {
    day: '2-digit', month: 'long', year: 'numeric',
  });
}

export default function HomePage() {
  const [news, setNews] = useState(null);
  const [nextEvent, setNextEvent] = useState(undefined);
  const [stats, setStats] = useState(null);

  useEffect(() => {
    api.get('/news').then((res) => setNews(res.data.slice(0, 4))).catch(() => setNews([]));
    api.get('/events').then((res) => {
      const upcoming = res.data
        .filter((e) => new Date(e.event_date) >= new Date())
        .sort((a, b) => new Date(a.event_date) - new Date(b.event_date));
      setNextEvent(upcoming[0] || null);
    }).catch(() => setNextEvent(null));
    api.get('/stats').then((res) => setStats(res.data)).catch(() => {});
  }, []);

  return (
    <section className="home-page">
      <div className="hero">
        <div className="hero-inner">
          <span className="hero-eyebrow">Знаменский собор · Кемерово</span>
          <h1>
            Православная <span className="accent">Молодёжь</span><br />
            Кемерово
          </h1>
          <p>
            Сообщество, в котором вера претворяется в добрые дела. Мы собираемся вместе,
            чтобы помогать людям, изучать традицию и быть полезными родному городу.
          </p>
          <div className="hero-actions">
            <Link to="/events" className="btn btn-primary">Хочу помогать</Link>
            <Link to="/about" className="btn btn-outline">Узнать больше</Link>
          </div>
        </div>

        <svg className="skyline" viewBox="0 0 1440 130" preserveAspectRatio="none" aria-hidden="true">
          <defs>
            <linearGradient id="dome" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#90EECA" />
              <stop offset="100%" stopColor="#76dab3" />
            </linearGradient>
          </defs>
          <path fill="#B4C4F7" d="M0,130 L0,90 Q60,75 120,90 L160,90 L160,60 Q170,40 180,60 L180,90 L260,90 L260,52 Q270,30 280,52 L280,90 L370,90 L370,30 Q390,5 410,30 L410,90 L500,90 L500,55 Q515,35 530,55 L530,90 L620,90 L620,38 Q640,12 660,38 L660,90 L760,90 L760,58 Q775,40 790,58 L790,90 L900,90 L900,25 Q925,-5 950,25 L950,90 L1060,90 L1060,55 Q1075,35 1090,55 L1090,90 L1190,90 L1190,45 Q1210,20 1230,45 L1230,90 L1330,90 L1330,60 Q1345,40 1360,60 L1360,90 L1440,90 L1440,130 Z" />
          <circle cx="180" cy="55" r="4" fill="url(#dome)" />
          <circle cx="280" cy="47" r="4" fill="url(#dome)" />
          <circle cx="390" cy="22" r="5" fill="url(#dome)" />
          <circle cx="515" cy="48" r="4" fill="url(#dome)" />
          <circle cx="640" cy="28" r="5" fill="url(#dome)" />
          <circle cx="775" cy="50" r="4" fill="url(#dome)" />
          <circle cx="925" cy="14" r="6" fill="url(#dome)" />
          <circle cx="1075" cy="48" r="4" fill="url(#dome)" />
          <circle cx="1210" cy="35" r="5" fill="url(#dome)" />
          <circle cx="1345" cy="50" r="4" fill="url(#dome)" />
        </svg>
      </div>

      {stats && (
        <FadeIn className="stats-grid">
          <div className="stat-card">
            <div className="stat-value"><AnimatedCounter value={stats.volunteers} /></div>
            <div className="stat-label">волонтёров</div>
          </div>
          <div className="stat-card">
            <div className="stat-value"><AnimatedCounter value={stats.events} /></div>
            <div className="stat-label">мероприятий</div>
          </div>
          <div className="stat-card">
            <div className="stat-value"><AnimatedCounter value={stats.applications_approved} /></div>
            <div className="stat-label">добрых дел</div>
          </div>
          <div className="stat-card">
            <div className="stat-value"><AnimatedCounter value={stats.news} /></div>
            <div className="stat-label">новостей</div>
          </div>
        </FadeIn>
      )}

      <div className="section-title">
        <h2>Ближайшее мероприятие</h2>
      </div>

      {nextEvent === undefined ? (
        <SkeletonCard />
      ) : nextEvent === null ? (
        <FadeIn className="card">
          <p className="hint">Пока ничего не запланировано — загляните позже.</p>
        </FadeIn>
      ) : (
        <FadeIn className="card">
          <div className="next-event">
            {nextEvent.photo_url && (
              <img src={nextEvent.photo_url} alt={nextEvent.title} className="next-event-photo" />
            )}
            <div>
              <h4>{nextEvent.title}</h4>
              <p className="hint">
                {formatDate(nextEvent.event_date)} · {nextEvent.location || 'Место уточняется'}
              </p>
              {nextEvent.description && (
                <p style={{ marginTop: 8 }}>{nextEvent.description}</p>
              )}
              <div style={{ marginTop: 14 }}>
                <Link to="/events" className="btn btn-primary btn-sm">Подробнее</Link>
              </div>
            </div>
          </div>
        </FadeIn>
      )}

      <div className="section-title">
        <h2>Истории и впечатления</h2>
      </div>

      <FeedSection />

      <div className="section-title">
        <h2>Последние новости</h2>
      </div>

      {news === null ? (
        <SkeletonCard />
      ) : news.length === 0 ? (
        <FadeIn className="card">
          <p className="hint">Пока новостей нет.</p>
        </FadeIn>
      ) : (
        <FadeIn className="card">
          <ul className="home-news-list">
            {news.map((n) => (
              <li key={n.id}>
                <Link to="/news">{n.title}</Link>
                <span className="hint"> · {formatDate(n.created_at)}</span>
              </li>
            ))}
          </ul>
          <div style={{ marginTop: 10 }}>
            <Link to="/news" className="btn btn-outline btn-sm">Все новости</Link>
          </div>
        </FadeIn>
      )}
    </section>
  );
}

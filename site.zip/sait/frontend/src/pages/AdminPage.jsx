import { useState } from 'react';
import AdminApplications from '../components/AdminApplications';
import AdminSupport from '../components/AdminSupport';

export default function AdminPage() {
  const [tab, setTab] = useState('applications');

  return (
    <section className="static-page">
      <div className="card">
        <h2>Админ-панель</h2>
        <p className="hint">
          Управление заявками волонтёров и обращениями в поддержку.
          Новости, мероприятия и состав СПМК редактируются на соответствующих страницах.
        </p>
      </div>

      <div className="view-tabs">
        <button className={tab === 'applications' ? 'active' : ''} onClick={() => setTab('applications')}>
          Заявки
        </button>
        <button className={tab === 'support' ? 'active' : ''} onClick={() => setTab('support')}>
          Обращения
        </button>
      </div>

      {tab === 'applications' && <AdminApplications />}
      {tab === 'support' && <AdminSupport />}
    </section>
  );
}

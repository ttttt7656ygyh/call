import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api/client';
import ImageUpload from './ImageUpload';

function formatDate(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleString('ru-RU', {
    day: '2-digit', month: 'long', hour: '2-digit', minute: '2-digit',
  });
}

export default function FeedSection() {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [draft, setDraft] = useState({ text: '', photo_url: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = () => {
    api.get('/feed').then((res) => setPosts(res.data)).catch(() => {});
  };

  useEffect(load, []);

  const submit = async (e) => {
    e.preventDefault();
    if (!draft.text.trim()) return;
    setBusy(true);
    setError('');
    try {
      await api.post('/feed', {
        text: draft.text,
        photo_url: draft.photo_url || null,
      });
      setDraft({ text: '', photo_url: '' });
      setShowForm(false);
      load();
    } catch (err) {
      setError(err.response?.data?.detail || 'Не удалось опубликовать');
    } finally {
      setBusy(false);
    }
  };

  const removePost = async (id) => {
    if (!window.confirm('Удалить пост?')) return;
    try {
      await api.delete(`/feed/${id}`);
      setPosts((prev) => prev.filter((p) => p.id !== id));
    } catch (err) {
      alert(err.response?.data?.detail || 'Не удалось удалить');
    }
  };

  return (
    <div>
      <div className="feed-head">
        {user ? (
          <button className="btn btn-primary btn-sm" onClick={() => setShowForm(!showForm)}>
            {showForm ? 'Отмена' : 'Поделиться историей'}
          </button>
        ) : (
          <p className="hint">Войдите, чтобы публиковать свои истории</p>
        )}
      </div>

      {showForm && (
        <form className="card feed-form" onSubmit={submit}>
          <textarea
            className="form-input"
            rows="4"
            placeholder="Расскажите о вашем опыте, впечатлении или поделитесь историей..."
            value={draft.text}
            onChange={(e) => setDraft({ ...draft, text: e.target.value })}
            required
          />
          <label>Фото (необязательно)</label>
          <ImageUpload
            value={draft.photo_url}
            onChange={(url) => setDraft({ ...draft, photo_url: url })}
          />
          {error && <p className="form-error">{error}</p>}
          <button type="submit" className="btn btn-primary" disabled={busy}>
            {busy ? 'Публикация...' : 'Опубликовать'}
          </button>
        </form>
      )}

      {posts.length === 0 ? (
        <div className="card">
          <p className="hint">Пока никто не поделился историей. Будьте первым!</p>
        </div>
      ) : (
        <div className="feed-list">
          {posts.map((p) => (
            <article key={p.id} className="card feed-post">
              <header className="feed-post-head">
                {p.author_avatar ? (
                  <img src={p.author_avatar} alt="" className="feed-avatar" />
                ) : (
                  <div className="feed-avatar placeholder">{p.author_name[0]}</div>
                )}
                <div>
                  <div className="feed-author">{p.author_name}</div>
                  <div className="hint">{formatDate(p.created_at)}</div>
                </div>
                {user && (user.id === p.author_id || user.role === 'admin') && (
                  <button className="btn btn-sm btn-ghost feed-remove" onClick={() => removePost(p.id)}>
                    Удалить
                  </button>
                )}
              </header>

              <p className="feed-text">{p.text}</p>
              {p.photo_url && <img src={p.photo_url} alt="" className="feed-photo" />}
            </article>
          ))}
        </div>
      )}
    </div>
  );
}

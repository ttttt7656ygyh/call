import { useMemo, useState } from 'react';

const MONTH_NAMES = [
  'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
  'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь',
];
const DOW = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

function sameDay(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function buildMonth(year, month) {
  const first = new Date(year, month, 1);
  const startWeekday = (first.getDay() + 6) % 7;
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const cells = [];
  for (let i = 0; i < startWeekday; i++) {
    cells.push({ date: new Date(year, month, -startWeekday + i + 1), muted: true });
  }
  for (let d = 1; d <= daysInMonth; d++) {
    cells.push({ date: new Date(year, month, d), muted: false });
  }
  while (cells.length % 7 !== 0) {
    const last = cells[cells.length - 1].date;
    cells.push({ date: new Date(last.getFullYear(), last.getMonth(), last.getDate() + 1), muted: true });
  }
  return cells;
}

export default function EventsCalendar({ events }) {
  const today = new Date();
  const [cursor, setCursor] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selected, setSelected] = useState(null);

  const eventsByDay = useMemo(() => {
    const map = new Map();
    for (const e of events) {
      const d = new Date(e.event_date);
      const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(e);
    }
    return map;
  }, [events]);

  const cells = useMemo(
    () => buildMonth(cursor.getFullYear(), cursor.getMonth()),
    [cursor]
  );

  const prev = () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1));
  const next = () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1));

  const selectedItems = selected
    ? eventsByDay.get(`${selected.getFullYear()}-${selected.getMonth()}-${selected.getDate()}`) || []
    : [];

  return (
    <div className="calendar">
      <div className="calendar-head">
        <button className="btn btn-ghost btn-sm" onClick={prev}>←</button>
        <h3>{MONTH_NAMES[cursor.getMonth()]} {cursor.getFullYear()}</h3>
        <button className="btn btn-ghost btn-sm" onClick={next}>→</button>
      </div>

      <div className="calendar-grid">
        {DOW.map((d) => <div key={d} className="calendar-dow">{d}</div>)}

        {cells.map(({ date, muted }) => {
          const key = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
          const items = eventsByDay.get(key) || [];
          const cls = [
            'calendar-day',
            muted ? 'muted' : '',
            sameDay(date, today) ? 'today' : '',
            items.length > 0 ? 'has-events' : '',
            selected && sameDay(date, selected) ? 'selected' : '',
          ].join(' ');

          return (
            <div
              key={date.toISOString()}
              className={cls}
              onClick={() => !muted && setSelected(date)}
            >
              <span className="day-num">{date.getDate()}</span>
              <div className="day-dots">
                {items.slice(0, 3).map((_, i) => <span key={i} className="day-dot" />)}
              </div>
            </div>
          );
        })}
      </div>

      {selected && (
        <div className="calendar-selected-list">
          <h4>
            {selected.getDate()} {MONTH_NAMES[selected.getMonth()].toLowerCase()} {selected.getFullYear()}
          </h4>
          {selectedItems.length === 0 ? (
            <p className="hint">В этот день мероприятий нет</p>
          ) : (
            selectedItems.map((e) => (
              <div key={e.id} className="item">
                <div>
                  <strong>{e.title}</strong>
                  {e.location && <div className="hint">{e.location}</div>}
                </div>
                <div className="hint">
                  {new Date(e.event_date).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../hooks/useTheme';
import AuthModal from './AuthModal';
import Footer from './Footer';
import NotificationBell from './NotificationBell';
import { IconSun, IconMoon } from './Icons';
import logoImg from '../assets/logo.png';

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  const [authModal, setAuthModal] = useState(null);

  const navLinks = [
    { to: '/', label: 'Главная' },
    { to: '/events', label: 'Мероприятия' },
    { to: '/news', label: 'Новости' },
    { to: '/about', label: 'О нас' },
    { to: '/support', label: 'Поддержка' },
    { to: '/profile', label: 'Профиль', requiresAuth: true },
    ...(user?.role === 'admin' ? [{ to: '/admin', label: 'Админ' }] : []),
  ];

  return (
    <>
      <nav className="navbar">
        <div className="logo" onClick={() => navigate('/')}>
          <img src={logoImg} alt="ПМК" />
          <span className="logo-text">ПМК Кемерово</span>
        </div>

        <div className="nav-links">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => (isActive ? 'active' : '')}
              onClick={(e) => {
                if (link.requiresAuth && !user) {
                  e.preventDefault();
                  setAuthModal('login');
                }
              }}
            >
              {link.label}
            </NavLink>
          ))}
        </div>

        <div className="header-actions">
          <NotificationBell user={user} />
          <button
            className="icon-btn"
            onClick={toggle}
            title={theme === 'light' ? 'Тёмная тема' : 'Светлая тема'}
          >
            {theme === 'light' ? <IconMoon /> : <IconSun />}
          </button>

          {user ? (
            <>
              <span className="user-name">{user.full_name || user.name}</span>
              <button
                className="btn btn-outline btn-sm"
                onClick={() => {
                  logout();
                  navigate('/');
                }}
              >
                Выйти
              </button>
            </>
          ) : (
            <button className="btn btn-primary btn-sm" onClick={() => setAuthModal('login')}>
              Войти
            </button>
          )}
        </div>
      </nav>

      <main className="main-content">{children}</main>

      <Footer />

      <AuthModal mode={authModal} onClose={() => setAuthModal(null)} />
    </>
  );
}

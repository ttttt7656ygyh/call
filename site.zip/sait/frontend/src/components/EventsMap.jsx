import { AttributionControl, MapContainer, Marker, Popup, TileLayer, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const KEMEROVO = [55.354968, 86.087314];
const OSM_ATTR = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>';

function ClickPicker({ onPick }) {
  useMapEvents({
    click(e) {
      onPick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

export function EventsMap({ events }) {
  const points = events.filter((e) => e.lat != null && e.lng != null);

  return (
    <div className="map-wrap">
      <MapContainer
        center={KEMEROVO}
        zoom={12}
        style={{ width: '100%', height: '100%' }}
        attributionControl={false}
      >
        <AttributionControl position="bottomright" prefix={false} />
        <TileLayer attribution={OSM_ATTR} url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {points.map((e) => (
          <Marker key={e.id} position={[e.lat, e.lng]}>
            <Popup>
              <strong>{e.title}</strong>
              <br />
              {new Date(e.event_date).toLocaleString('ru-RU', {
                day: '2-digit', month: 'long', hour: '2-digit', minute: '2-digit',
              })}
              {e.location && <><br />{e.location}</>}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}

export function LocationPicker({ value, onChange, height = 280 }) {
  const center = value ? [value.lat, value.lng] : KEMEROVO;

  return (
    <div className="map-wrap" style={{ height }}>
      <MapContainer
        center={center}
        zoom={12}
        style={{ width: '100%', height: '100%' }}
        attributionControl={false}
      >
        <AttributionControl position="bottomright" prefix={false} />
        <TileLayer attribution={OSM_ATTR} url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <ClickPicker onPick={(lat, lng) => onChange({ lat, lng })} />
        {value && <Marker position={[value.lat, value.lng]} />}
      </MapContainer>
    </div>
  );
}

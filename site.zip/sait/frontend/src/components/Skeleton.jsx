export function SkeletonLine({ size = '' }) {
  return <div className={`skeleton skeleton-line ${size}`} />;
}

export function SkeletonCard() {
  return (
    <div className="card">
      <div className="skeleton skeleton-block" style={{ marginBottom: 14 }} />
      <SkeletonLine size="lg" />
      <SkeletonLine />
      <SkeletonLine />
      <SkeletonLine size="xs" />
    </div>
  );
}

export function SkeletonRow() {
  return (
    <div className="card" style={{ padding: '1rem' }}>
      <SkeletonLine size="lg" />
      <SkeletonLine />
    </div>
  );
}

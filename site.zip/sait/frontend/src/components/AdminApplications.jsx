import { useEffect, useState } from 'react';
import api from '../api/client';

const STATUS_LABELS = {
  pending: 'Ожидает',
  approved: 'Одобрено',
  rejected: 'Отклонено',
};

function formatDateTime(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('ru-RU', {
    day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

function UserCardModal({ userId, onClose }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get(`/admin/users/${userId}`)
      .then((res) => setData(res.data))
      .catch((err) => setError(err.response?.data?.detail || 'Не удалось загрузить'));
  }, [userId]);

  return (
    <div className="modal" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h3 className="modal-title">Карточка волонтёра</h3>

        {error && <p className="form-error">{error}</p>}

        {data ? (
          <>
            <div style={{ textAlign: 'center', marginBottom: '1rem' }}>
              {data.avatar ? (
                <img src={data.avatar} alt="" className="profile-avatar" />
              ) : (
                <div className="profile-avatar placeholder">{(data.name || '?')[0]}</div>
              )}
              <h3 style={{ marginTop: 8 }}>{data.full_name || data.name}</h3>
              <p className="profile-role">{data.role === 'admin' ? 'Администратор' : 'Волонтёр'}</p>
            </div>

            <div>
              <div className="user-card-row">
                <span className="label">Логин</span>
                <span className="value">{data.login}</span>
              </div>
              <div className="user-card-row">
                <span className="label">Телефон</span>
                <span className="value">{data.phone || '—'}</span>
              </div>
              <div className="user-card-row">
                <span className="label">Email</span>
                <span className="value">{data.email || '—'}</span>
              </div>
              <div className="user-card-row">
                <span className="label">Возраст</span>
                <span className="value">{data.age || '—'}</span>
              </div>
              <div className="user-card-row">
                <span className="label">Регистрация</span>
                <span className="value">{formatDateTime(data.created_at)}</span>
              </div>
              <div className="user-card-row">
                <span className="label">Всего заявок</span>
                <span className="value">{data.applications_total}</span>
              </div>
              <div className="user-card-row">
                <span className="label">Одобрено</span>
                <span className="value">{data.applications_approved}</span>
              </div>
            </div>

            <button className="btn btn-outline btn-block" onClick={onClose}>Закрыть</button>
          </>
        ) : !error ? (
          <p className="hint">Загрузка...</p>
        ) : null}
      </div>
    </div>
  );
}

export default function AdminApplications() {
  const [apps, setApps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const [userModal, setUserModal] = useState(null);

  const load = () => {
    setLoading(true);
    api.get('/admin/applications')
      .then((res) => { setApps(res.data); setError(null); })
      .catch((err) => setError(err.response?.data?.detail || 'Не удалось загрузить заявки'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const changeStatus = async (id, status) => {
    setBusyId(id);
    try {
      await api.patch(`/admin/applications/${id}`, { status });
      setApps((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
    } catch (err) {
      alert(err.response?.data?.detail || 'Не удалось изменить статус');
    } finally {
      setBusyId(null);
    }
  };

  if (loading) return <p className="hint">Загрузка заявок...</p>;

  if (error) {
    return (
      <div className="card alert-card">
        <h3>Ошибка</h3>
        <p>{error}</p>
        <button className="btn btn-outline" onClick={load}>Повторить</button>
      </div>
    );
  }

  if (apps.length === 0) return <p className="hint">Заявок пока нет</p>;

  return (
    <div className="card admin-apps">
      <h3>Входящие заявки ({apps.length})</h3>
      <div className="table-wrap">
        <table className="apps-table">
          <thead>
            <tr>
              <th>Мероприятие</th>
              <th>Волонтёр</th>
              <th>Сообщение</th>
              <th>Статус</th>
              <th>Действия</th>
            </tr>
          </thead>
          <tbody>
            {apps.map((app) => (
              <tr key={app.id}>
                <td>{app.event_title}</td>
                <td>
                  <button className="user-link" onClick={() => setUserModal(app.user_id)}>
                    {app.user_name}
                  </button>
                </td>
                <td className="msg-cell">{app.message || '—'}</td>
                <td>
                  <span className={`badge badge-${app.status}`}>
                    {STATUS_LABELS[app.status] || app.status}
                  </span>
                </td>
                <td>
                  {app.status !== 'approved' && (
                    <button
                      className="btn btn-sm btn-primary"
                      disabled={busyId === app.id}
                      onClick={() => changeStatus(app.id, 'approved')}
                    >
                      Одобрить
                    </button>
                  )}
                  {app.status !== 'rejected' && (
                    <button
                      className="btn btn-sm btn-outline"
                      disabled={busyId === app.id}
                      onClick={() => changeStatus(app.id, 'rejected')}
                    >
                      Отклонить
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {userModal && <UserCardModal userId={userModal} onClose={() => setUserModal(null)} />}
    </div>
  );
}

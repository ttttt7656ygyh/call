export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-content">
        <p>© {new Date().getFullYear()} ПМК — Знаменский Собор Кемерово</p>
        <p className="footer-motto">Живём по вере, служим с любовью</p>
      </div>
    </footer>
  );
}

export default function CategoryChips({ categories, value, onChange }) {
  return (
    <div className="chips">
      <button
        className={`chip ${!value ? 'active' : ''}`}
        onClick={() => onChange('')}
        type="button"
      >
        Все
      </button>
      {categories.map((c) => (
        <button
          key={c.key}
          className={`chip ${value === c.key ? 'active' : ''}`}
          onClick={() => onChange(c.key)}
          type="button"
        >
          {c.label}
        </button>
      ))}
    </div>
  );
}

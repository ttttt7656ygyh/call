import { useInView } from '../hooks/useInView';

export default function FadeIn({ children, delay = 0, as: Tag = 'div', className = '', ...rest }) {
  const [ref, inView] = useInView();
  const style = delay ? { transitionDelay: `${delay}ms` } : undefined;
  return (
    <Tag ref={ref} className={`fade-in ${inView ? 'visible' : ''} ${className}`} style={style} {...rest}>
      {children}
    </Tag>
  );
}

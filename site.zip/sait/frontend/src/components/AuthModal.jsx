import { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function AuthModal({ mode, onClose }) {
  const { login, register } = useAuth();
  const [isLogin, setIsLogin] = useState(mode === 'login');
  const [form, setForm] = useState({ name: '', login: '', pass: '' });
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setInfo('');
    setLoading(true);

    try {
      if (isLogin) {
        await login(form.login, form.pass);
        onClose();
      } else {
        await register(form.name, form.login, form.pass);
        setInfo('Аккаунт создан, теперь войдите');
        setIsLogin(true);
        setForm({ name: '', login: form.login, pass: '' });
      }
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'Ошибка');
    } finally {
      setLoading(false);
    }
  };

  if (!mode) return null;

  return (
    <div className="modal" onClick={onClose}>
      <div className="modal-content card" onClick={(e) => e.stopPropagation()}>
        <h3 className="modal-title">{isLogin ? 'Вход' : 'Регистрация'}</h3>

        <form onSubmit={handleSubmit}>
          {!isLogin && (
            <input
              type="text"
              className="form-input"
              placeholder="Имя"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
          )}
          <input
            type="text"
            className="form-input"
            placeholder="Логин"
            value={form.login}
            onChange={(e) => setForm({ ...form, login: e.target.value })}
            required
          />
          <input
            type="password"
            className="form-input"
            placeholder="Пароль"
            value={form.pass}
            onChange={(e) => setForm({ ...form, pass: e.target.value })}
            required
          />

          {error && <p className="form-error">{error}</p>}
          {info && <p className="form-info">{info}</p>}

          <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
            {loading ? 'Загрузка...' : isLogin ? 'Войти' : 'Создать аккаунт'}
          </button>
        </form>

        <p className="modal-switch">
          <span onClick={() => { setIsLogin(!isLogin); setError(''); setInfo(''); }}>
            {isLogin ? 'Нет аккаунта? Регистрация' : 'Уже есть аккаунт? Войти'}
          </span>
        </p>

        <button className="btn btn-outline btn-block" onClick={onClose}>
          Закрыть
        </button>
      </div>
    </div>
  );
}

import { useRef, useState } from 'react';
import api from '../api/client';
import { IconUpload } from './Icons';

export default function ImageUpload({ value, onChange }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const handleFile = async (file) => {
    if (!file) return;
    setError('');
    setBusy(true);
    try {
      const form = new FormData();
      form.append('file', file);
      const { data } = await api.post('/upload', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      onChange(data.url);
    } catch (err) {
      setError(err.response?.data?.detail || 'Не удалось загрузить');
    } finally {
      setBusy(false);
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  return (
    <div
      className={`image-upload ${value ? 'has-image' : ''}`}
      onClick={() => !value && inputRef.current?.click()}
      onDragOver={(e) => e.preventDefault()}
      onDrop={onDrop}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        style={{ display: 'none' }}
        onChange={(e) => handleFile(e.target.files?.[0])}
      />

      {value ? (
        <>
          <img src={value} alt="" />
          <button
            type="button"
            className="upload-clear"
            onClick={(e) => { e.stopPropagation(); onChange(''); }}
          >
            Убрать
          </button>
        </>
      ) : busy ? (
        <p className="upload-hint">Загрузка...</p>
      ) : (
        <>
          <IconUpload />
          <p style={{ marginTop: 6, fontWeight: 600 }}>Перетащите фото или нажмите</p>
          <p className="upload-hint">PNG, JPG, WEBP до 5 МБ</p>
          {error && <p className="form-error">{error}</p>}
        </>
      )}
    </div>
  );
}

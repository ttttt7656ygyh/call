import { useEffect, useRef, useState } from 'react';
import api from '../api/client';
import { IconBell } from './Icons';

const SEEN_KEY = 'pmk_notif_seen';

export default function NotificationBell({ user }) {
  const [data, setData] = useState(null);
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;

    const load = () => {
      api.get('/notifications')
        .then((res) => { if (!cancelled) setData(res.data); })
        .catch(() => {});
    };
    load();
    const id = setInterval(load, 30000);

    return () => { cancelled = true; clearInterval(id); };
  }, [user]);

  useEffect(() => {
    const onClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  if (!user || !data) return null;

  const seen = Number(localStorage.getItem(SEEN_KEY + '_' + user.id) || 0);
  const fresh = user.role === 'admin' ? data.count : Math.max(0, data.count - seen);

  const handleOpen = () => {
    setOpen((v) => !v);
    if (!open && user.role === 'user') {
      localStorage.setItem(SEEN_KEY + '_' + user.id, String(data.count));
    }
  };

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button className="icon-btn" onClick={handleOpen} title="Уведомления">
        <IconBell />
        {fresh > 0 && <span className="badge-dot">{fresh}</span>}
      </button>

      {open && (
        <div className="notification-menu">
          <h4>Уведомления</h4>
          {user.role === 'admin' ? (
            data.count > 0 ? (
              <ul>
                <li>Новых заявок волонтёров: <strong>{data.count}</strong></li>
                <li className="hint">Перейдите в админ-панель для обработки</li>
              </ul>
            ) : (
              <div className="empty">Новых заявок нет</div>
            )
          ) : data.items && data.items.length > 0 ? (
            <ul>
              {data.items.map((it) => (
                <li key={it.id}>
                  <strong>{it.event_title}</strong>
                  <div className={`badge badge-${it.status}`} style={{ marginTop: 4 }}>
                    {it.status === 'approved' ? 'Одобрено' : 'Отклонено'}
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="empty">Уведомлений нет</div>
          )}
        </div>
      )}
    </div>
  );
}

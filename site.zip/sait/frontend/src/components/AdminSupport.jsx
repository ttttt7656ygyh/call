import { useEffect, useState } from 'react';
import api from '../api/client';

const STATUS_LABELS = {
  open: 'Открыто',
  answered: 'Есть ответ',
  closed: 'Закрыто',
};

function formatDateTime(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleString('ru-RU', {
    day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

export default function AdminSupport() {
  const [tickets, setTickets] = useState(null);
  const [replyDraft, setReplyDraft] = useState({});
  const [error, setError] = useState(null);

  const load = () => {
    api.get('/admin/support')
      .then((res) => { setTickets(res.data); setError(null); })
      .catch((err) => setError(err.response?.data?.detail || 'Не удалось загрузить'));
  };

  useEffect(load, []);

  const sendReply = async (ticketId) => {
    const text = (replyDraft[ticketId] || '').trim();
    if (!text) return;
    try {
      await api.post(`/admin/support/${ticketId}/reply`, { text });
      setReplyDraft({ ...replyDraft, [ticketId]: '' });
      load();
    } catch (err) {
      alert(err.response?.data?.detail || 'Не удалось ответить');
    }
  };

  const setStatus = async (ticketId, status) => {
    try {
      await api.patch(`/admin/support/${ticketId}`, { status });
      load();
    } catch (err) {
      alert(err.response?.data?.detail || 'Не удалось изменить статус');
    }
  };

  if (tickets === null) return <p className="hint">Загрузка обращений...</p>;
  if (error) return <div className="card alert-card"><p>{error}</p></div>;
  if (tickets.length === 0) return <p className="hint">Обращений пока нет</p>;

  return (
    <div className="tickets-list">
      {tickets.map((t) => (
        <div key={t.id} className="card ticket-card">
          <div className="ticket-head">
            <div>
              <div className="ticket-subject">{t.subject}</div>
              <div className="ticket-meta">
                От {t.user_name} {t.user_email && `· ${t.user_email}`} · {formatDateTime(t.created_at)}
              </div>
            </div>
            <span className={`badge badge-${t.status}`}>
              {STATUS_LABELS[t.status] || t.status}
            </span>
          </div>

          <div className="ticket-text">{t.text}</div>

          {t.replies.length > 0 && (
            <div className="ticket-replies">
              {t.replies.map((r) => (
                <div key={r.id} className={`ticket-reply ${r.is_admin ? 'from-admin' : ''}`}>
                  <div className="ticket-reply-author">
                    {r.author_name} {r.is_admin && '(админ)'}
                    <span className="ticket-meta" style={{ marginLeft: 8 }}>
                      {formatDateTime(r.created_at)}
                    </span>
                  </div>
                  <div style={{ whiteSpace: 'pre-wrap' }}>{r.text}</div>
                </div>
              ))}
            </div>
          )}

          {t.status !== 'closed' && (
            <div className="comment-form" style={{ marginTop: '1rem' }}>
              <input
                type="text"
                className="form-input"
                placeholder="Написать ответ..."
                value={replyDraft[t.id] || ''}
                onChange={(e) => setReplyDraft({ ...replyDraft, [t.id]: e.target.value })}
              />
              <button className="btn btn-primary btn-sm" onClick={() => sendReply(t.id)}>
                Ответить
              </button>
            </div>
          )}

          <div style={{ display: 'flex', gap: 6, marginTop: '0.8rem' }}>
            {t.status !== 'closed' ? (
              <button className="btn btn-sm btn-outline" onClick={() => setStatus(t.id, 'closed')}>
                Закрыть
              </button>
            ) : (
              <button className="btn btn-sm btn-outline" onClick={() => setStatus(t.id, 'open')}>
                Переоткрыть
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
